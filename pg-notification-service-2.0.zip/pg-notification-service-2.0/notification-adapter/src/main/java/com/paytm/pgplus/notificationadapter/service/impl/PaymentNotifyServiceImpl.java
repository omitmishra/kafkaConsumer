package com.paytm.pgplus.notificationadapter.service.impl;

import com.fasterxml.jackson.annotation.JacksonAnnotationsInside;
import com.paytm.pg.common.structures.PayOptionDetailDTO;
import com.paytm.pg.common.structures.PaymentViewDTO;
import com.paytm.pg.dto.acquiring.PaymentNotifyDTO;
import com.paytm.pgplus.notificationadapter.helper.JsonMapper;
import com.paytm.pgplus.notificationadapter.helper.PayloadHelperService;
import com.paytm.pgplus.notificationadapter.http.service.impl.AdapterClientImpl;
import com.paytm.pgplus.notificationadapter.model.Money;
import com.paytm.pgplus.notificationadapter.model.PaymentView;
import com.paytm.pgplus.notificationadapter.model.paymentNotify.PayChannelInfo;
import com.paytm.pgplus.notificationadapter.model.paymentNotify.PayOptionInfo;
import com.paytm.pgplus.notificationadapter.model.paymentNotify.PaymentNotifyRequestBody;
import com.paytm.pgplus.notificationadapter.service.IProcessNotificationAdapterService;

import org.apache.commons.collections4.CollectionUtils;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;


@Service(value = "paymentNotifyServiceImpl")
public class PaymentNotifyServiceImpl implements IProcessNotificationAdapterService {

    private static final Logger log = LoggerFactory.getLogger(PaymentNotifyServiceImpl.class);

    @Autowired
    AdapterClientImpl adapterClientImpl;

    @Autowired
    PayloadHelperService payloadHelperService;

    @Override
    public Runnable createNotifierJob(final String kafkaPayload) {
        return new Runnable() {
            @Override
            public void run() {
               if (null != kafkaPayload) {
                    try {
                        PaymentNotifyRequestBody body = processPaymentNotify(kafkaPayload);
                        adapterClientImpl.processPaymentNotify(payloadHelperService.getPaymentNotifyPayload(body));
                    } catch (final Exception ex) {
                        log.error("Exception occurred while processing PaymentNotifyRequest:{}", ex);
                    }
                } else {
                   log.error("Invalid request received for PaymentNotifyRequest");
                }

            }
        };
    }

    private PaymentNotifyRequestBody processPaymentNotify(String payload){
        PaymentNotifyRequestBody paymentNotifyRequestBody = new PaymentNotifyRequestBody();
        try{
            PaymentNotifyDTO paymentNotifyDTO = JsonMapper.mapJsonToObject(payload, PaymentNotifyDTO.class);

            paymentNotifyRequestBody.setAcquirementId(paymentNotifyDTO.getAcquirementId());
            paymentNotifyRequestBody.setMerchantTransId(paymentNotifyDTO.getMerchantTransId());
            paymentNotifyRequestBody.setCreatedTime(paymentNotifyDTO.getCreatedTime());
            paymentNotifyRequestBody.setMerchantId(paymentNotifyDTO.getMerchantId());
            paymentNotifyRequestBody.setMerchantName(paymentNotifyDTO.getMerchantName());

            Money orderAmount = new Money();
            if (paymentNotifyDTO.getOrderAmount() != null){
                orderAmount.setValue(paymentNotifyDTO.getOrderAmount().getCurrencyValue());
                if (paymentNotifyDTO.getOrderAmount().getCurrency() != null)
                    orderAmount.setCurrency(paymentNotifyDTO.getOrderAmount().getCurrency().getCurrencyCode());
            }
            paymentNotifyRequestBody.setOrderAmount(orderAmount);

            paymentNotifyRequestBody.setOrderStatus(paymentNotifyDTO.getOrderStatus());

            if(paymentNotifyDTO.getPaymentView() != null){
                setPaymentView(paymentNotifyRequestBody, paymentNotifyDTO);
            }
            paymentNotifyRequestBody.setOrderExtendInfo(paymentNotifyDTO.getOrderExtendInfo());
            //bizExtendInfo not needed in UPI_PUSH but needed elsewhere
            paymentNotifyRequestBody.setPayResult(paymentNotifyDTO.getPayResult());
            //requeCount we will need to set
            paymentNotifyRequestBody.setExtendInfo(paymentNotifyDTO.getExtendInfo());
            paymentNotifyRequestBody.setProductCode(paymentNotifyDTO.getProductCode());
            paymentNotifyRequestBody.setAcquireMode(paymentNotifyDTO.getAcquireMode());
           // JsonMapper.mapObjectToJson(paymentNotifyRequestBody);
        } catch (Exception e){
            log.error("Some Exception {} occurred during mapping of paymentNotifyDTO to paymentNotifyRequestBody for payload: {}", e,payload);
        }
        return paymentNotifyRequestBody;
    }

    private void setPaymentView(PaymentNotifyRequestBody paymentNotifyRequestBody, PaymentNotifyDTO paymentNotifyDTO){
        PaymentView paymentView = new PaymentView();
        PaymentViewDTO paymentViewDTO = paymentNotifyDTO.getPaymentView();
        try{
            paymentView.setCashierRequestId(paymentViewDTO.getCashierRequestId());
            paymentView.setPaidTime(paymentViewDTO.getPaidTime());
            paymentView.setRevoked(paymentViewDTO.isRevoked());
            paymentView.setPayRequestExtendInfo(paymentViewDTO.getPayRequestExtendInfo());
            paymentView.setExtendInfo(paymentViewDTO.getExtendInfo());
            if (CollectionUtils.isNotEmpty(paymentViewDTO.getPayOptionInfos()))
                setPayOptionInfos(paymentView, paymentViewDTO.getPayOptionInfos());
            paymentNotifyRequestBody.setPaymentView(paymentView);
        } catch(Exception e){
            log.error("Some exception occurred in setPaymentViews", e);
        }
    }

    private void setPayOptionInfos(PaymentView paymentView, List<PayOptionDetailDTO> payOptionInfosDTO){
        try{
            List<PayOptionInfo> payOptionInfos = new ArrayList<>();
            for (PayOptionDetailDTO payOptionDetailDTO : payOptionInfosDTO){
                PayOptionInfo payOptionInfo = new PayOptionInfo();
                payOptionInfo.setPayMethod(payOptionDetailDTO.getPayMethod());
                payOptionInfo.setPayOptionBillExtendInfo(payOptionDetailDTO.getPayOptionBillExtendInfo());

                Money payAmount = new Money();
                payAmount.setCurrency(payOptionDetailDTO.getPayAmount().getCurrency().getCurrencyCode());
                payAmount.setValue(payOptionDetailDTO.getPayAmount().getCurrencyValue());
                payOptionInfo.setPayAmount(payAmount);

                Money transAmount = new Money();
                transAmount.setCurrency(payOptionDetailDTO.getTransAmount().getCurrency().getCurrencyCode());
                transAmount.setValue(payOptionDetailDTO.getTransAmount().getCurrencyValue());
                payOptionInfo.setTransAmount(transAmount);

                //chargeAmount not in scope
                //revoked to be clarified
                payOptionInfo.setExtendInfo(payOptionDetailDTO.getExtendInfo());

                PayChannelInfo payChannelInfo = new PayChannelInfo();
                payChannelInfo.setVirtualPaymentAddr(payOptionDetailDTO.getPayChannelInfo().getVirtualPaymentAddr());
                payChannelInfo.setPayerVpaCustomerId(payOptionDetailDTO.getPayChannelInfo().getPayerVpaCustomerId());
                payChannelInfo.setPayOption(payOptionDetailDTO.getPayChannelInfo().getPayOption());
                payOptionInfo.setPayChannelInfo(payChannelInfo);
                //dccPaymentInfo not needed for UPI_PUSH but needed in general
                payOptionInfos.add(payOptionInfo);
            }
            PayOptionInfo[] payOptionInfoArr=payOptionInfos.stream().toArray(n ->new PayOptionInfo[n]);
            paymentView.setPayOptionInfos(payOptionInfoArr);
        } catch (Exception e){
            log.error("Some exception occurred in setPayOptionInfos", e);
        }
    }

}
