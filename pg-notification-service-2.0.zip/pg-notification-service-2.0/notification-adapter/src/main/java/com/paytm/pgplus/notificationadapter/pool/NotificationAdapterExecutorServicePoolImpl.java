package com.paytm.pgplus.notificationadapter.pool;


import com.paytm.pgplus.notificationadapter.config.ApplicationConfig;
import com.paytm.pgplus.notificationadapter.controlcenter.IApplicationCentre;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@Service(value = "notificationAdapterExecutorServicePoolImpl")
public final class NotificationAdapterExecutorServicePoolImpl implements IExecutorServicePool {

        private static final Logger LOGGER = LoggerFactory.getLogger(NotificationAdapterExecutorServicePoolImpl.class);

        private static ThreadPoolExecutor servicePool;

        @Autowired
        private ApplicationConfig applicationConfig;

        @Autowired
        @Qualifier("notificationAdapterApplicationCentreImpl")
        private IApplicationCentre applicationCentre;

        @PostConstruct
        private void initNotificationServicePool() {
            servicePool = new ThreadPoolExecutor(applicationConfig.getMinPoolSize(), applicationConfig.getMaxPoolSize(), applicationConfig.getKeepAliveTimeInMillis(),
                    TimeUnit.SECONDS, new SynchronousQueue<Runnable>(), new ThreadFactory() {
                private final AtomicInteger threadCount = new AtomicInteger();

                @Override
                public Thread newThread(final Runnable target) {
                    return new Thread(target, new StringBuilder("Notification Adaptor Thread-").append(
                            threadCount.incrementAndGet()).toString());
                }
            }, new ThreadPoolExecutor.CallerRunsPolicy());
        }

        @Override
        public void submitJob(final Runnable task) throws InterruptedException {
            if (applicationCentre.isStopped()) {
                throw new InterruptedException("Notification Adaptor Application Already stoped!");
            }
            servicePool.submit(task);
            LOGGER.info(
                    "Notification Adaptor ExecutorServicePool Task Submitted, Largest Pool Size :{}, Max Pool Size :{}, Queue Size :{}, Current Pool Size :{},  Active Count :{}, ",
                    servicePool.getLargestPoolSize(), servicePool.getMaximumPoolSize(), servicePool.getQueue().size(),
                    servicePool.getPoolSize(), servicePool.getActiveCount());
            }

        @Override
        public void shutDown() throws InterruptedException {
            servicePool.shutdown();
            if (!servicePool.awaitTermination(applicationConfig.getAppShutDownTimeInMillis(), TimeUnit.MILLISECONDS)) {
                LOGGER.warn("Notification Adaptor pool did not terminate in the specified time : {} ms",
                        applicationConfig.getAppShutDownTimeInMillis());
                final List<Runnable> droppedTasks = servicePool.shutdownNow();
                LOGGER.warn(
                        "Notification Adaptor pool was abruptly shut down. Total {} Notification Adaptor operation will not be executed.",
                        droppedTasks.size());
            }
        }

    }
