package com.paytm.pgplus.notificationadapter.model;



import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Money implements Serializable {

    private static final long serialVersionUID = -7791446199325328427L;

    /**
     * 3-letter currency code
     */
    @NotBlank(message = "{notblank}")
    private String value;

    @NotBlank(message = "{notblank}")
    @Length(max = 3, message = "{lengthlimit}")
    private String currency;

    /**
     * @return the currency
     */
    public String getCurrency() {
        return currency;
    }

    /**
     * @param currency
     *            the currency to set
     */
    public void setCurrency(String currency) {
        this.currency = currency;
    }

    /**
     * @return the value
     */
    public String getValue() {
        return value;
    }

    /**
     * @param value
     *            the value to set
     */
    public void setValue(String value) {
        this.value = value;
    }
}

