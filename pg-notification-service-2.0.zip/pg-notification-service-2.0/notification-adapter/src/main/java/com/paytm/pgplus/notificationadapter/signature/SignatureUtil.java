package com.paytm.pgplus.notificationadapter.signature;

import com.paytm.pgplus.notificationadapter.config.ConfigValues;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.*;
import java.util.List;
import java.util.Properties;

@Configuration
public class SignatureUtil {
    private static final Logger LOGGER = LoggerFactory.getLogger(SignatureUtil.class);
    private final static Properties properties = ConfigValues.getProperties();
    private static final String SHA256_KEY_LOCATION = properties.getProperty("signature.sha256.key.location");
            //"/home/ravishankar/Downloads/keys/SHA256";
    private static final String SIGNATURE_ALGORITHM_LOCATION = properties.getProperty("signature.algorithm.location");
                    //"/home/ravishankar/Downloads/keys/Algo";

    public static String sha256Key;


    static {
        try {
            loadSHA256Key();

            new Thread(new SignatureModificationListener()).start();
        } catch (Exception e) {
            LOGGER.error("Unable to load this class", e);
            throw e;
        }
    }


    static class SignatureModificationListener implements Runnable {

        @Override
        public void run() {
            WatchService watchService;
            try {
                watchService = FileSystems.getDefault().newWatchService();
                int lastIndex = SIGNATURE_ALGORITHM_LOCATION.lastIndexOf("/");
                String dirPath = SIGNATURE_ALGORITHM_LOCATION.substring(0, lastIndex + 1);
                Path path = Paths.get(dirPath);
                path.register(watchService, StandardWatchEventKinds.ENTRY_CREATE, StandardWatchEventKinds.ENTRY_MODIFY);
                int MAX_RELOAD_RETRY = Integer.parseInt(properties.getProperty("signature.config.max.reload.retry"));
                int SLEEP_BETWEEN_RELOAD_RETRY = Integer.parseInt(properties.getProperty("signature.config.reload.sleep.between.retry"));
                int count = 0;
                WatchKey key = null;
                List<WatchEvent<?>> watchEvents = null;
                long start = System.currentTimeMillis();
                while (true) {
                    try {
                        if (!(watchEvents != null && !watchEvents.isEmpty())) {
                            count = 0;
                            if (key != null) {
                                if (!key.reset()) {
                                    LOGGER.error("Could not reset the signature watch key , Directory is inaccessible");
                                    break;
                                }
                            }
                            key = watchService.take();
                            watchEvents = key.pollEvents();
                        } else {
                            // previous looEPayMethodp was unsuccessful
                            if (count++ == MAX_RELOAD_RETRY) {
                                // clear pending events to wait for further
                                // replacement
                                watchEvents.remove(0);
                            }
                            Thread.sleep(SLEEP_BETWEEN_RELOAD_RETRY);
                        }
                        start = System.currentTimeMillis();
                        WatchEvent<?> event;
                        while (!watchEvents.isEmpty()) {
                            event = watchEvents.get(0);
                            @SuppressWarnings("unchecked")
                            WatchEvent.Kind<Path> kind = (WatchEvent.Kind<Path>) event.kind();
                            if (StandardWatchEventKinds.ENTRY_MODIFY.equals(kind)) {
                                String fileName = event.context().toString();
                                String fileLocation = dirPath + fileName;
                                reloadSignatureConfig(fileLocation);
                            }
                            watchEvents.remove(0);
                        }
                        LOGGER.info("Reloaded config in : {} ms", System.currentTimeMillis() - start);
                    } catch (InterruptedException ex) {
                        LOGGER.error("Error in obtaining Signature watch key");
                    } catch (Exception e) {
                        LOGGER.error("Error occurred while looping for pending watch events ");
                        continue;
                    }
                }
            } catch (IOException e) {
                LOGGER.error("Exception occured in Signature modification watcher", e);
            } catch (Exception ex) {
                LOGGER.error("Exception occured in Signature modification watcher", ex);
            }
        }
    }

    public static void reloadSignatureConfig(final String fileLocation) {
       if (SHA256_KEY_LOCATION.equals(fileLocation)) {
            loadSHA256Key();
        }
    }

    public static void loadSHA256Key() {
        File sha256File = new File(SHA256_KEY_LOCATION);
        try (InputStream sha256KeyFile = new FileInputStream(sha256File)) {
            sha256Key = getFileContent(sha256KeyFile);
            if (sha256Key != null) {
                sha256Key = sha256Key.trim();
            }
        } catch (Exception e) {
            LOGGER.error("Problem in loading SHA256Key, due to ", e);
            throw new IllegalArgumentException(e);
        }
    }


    private static String getFileContent(InputStream inStrem) throws IOException {
        int ch;
        StringBuffer strContent = new StringBuffer("");
        while ((ch = inStrem.read()) != -1)
            strContent.append((char) ch);
        return strContent.toString();
    }


}
