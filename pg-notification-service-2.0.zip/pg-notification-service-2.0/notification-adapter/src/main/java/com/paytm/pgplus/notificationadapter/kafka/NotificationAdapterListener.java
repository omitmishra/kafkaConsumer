package com.paytm.pgplus.notificationadapter.kafka;


import com.paytm.pgplus.notificationadapter.service.BusinessProcessor;
import com.paytm.pgplus.notificationadapter.topics.KafkaTopics;
import com.paytm.pgplus.notificationadapter.util.KafkaConsumerUtil;
import com.paytm.pgplus.notificationadapter.util.NotificationAdapterConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class NotificationAdapterListener {

    private static final Logger LOGGER = LoggerFactory.getLogger(NotificationAdapterListener.class);

    @Autowired
    private KafkaConsumerUtil kafkaConsumerUtil;

    @Autowired
    @Qualifier("paymentNotifyConsumerServiceImpl")
    private BusinessProcessor paymentNotifyConsumerService;

    @Autowired
    @Qualifier("closeNotifyConsumerServiceImpl")
    private BusinessProcessor closeNotifyConsumerService;

    @Autowired
    @Qualifier("retryPaymentNotifyConsumerServiceImpl")
    private BusinessProcessor retryPaymentNotifyConsumerServiceImpl;

    @Autowired
    @Qualifier("retryCloseNotifyConsumerServiceImpl")
    private BusinessProcessor retryCloseNotifyConsumerServiceImpl;

    @Autowired
    @Qualifier("kafkaProducerTemplate")
    private KafkaTemplate<String, String> template;

    @KafkaListener(topics = KafkaTopics.TOPIC_PAYMENT_NOTIFY,groupId = NotificationAdapterConstants.KAFKA_GROUP_PAYMENT_NOTIFY)
    void paymentNotifyCC(String payload) {
        LOGGER.info("Payload received for paymentNotify: {}", payload);
        kafkaConsumerUtil.preConsume();
        paymentNotifyConsumerService.process(payload);
    }


    @KafkaListener(topics = KafkaTopics.TOPIC_CLOSE_ORDER_NOTIFY, groupId = NotificationAdapterConstants.KAFKA_GROUP_CLOSE_NOTIFY)
    void closeNotifyCC(String payload) {
        LOGGER.info("Payload received for closeNotify: {}", payload);
        kafkaConsumerUtil.preConsume();
        closeNotifyConsumerService.process(payload);
    }

    @KafkaListener(topics = KafkaTopics.TOPIC_PAYMENT_NOTIFY_RETRY ,groupId = NotificationAdapterConstants.KAFKA_GROUP_PAYMENT_NOTIFY)
    void paymentNotifyRetry(String payload) {
        LOGGER.info("Payload received for paymentNotifyRetry: {}", payload);
        kafkaConsumerUtil.preConsume();
        retryPaymentNotifyConsumerServiceImpl.process(payload);
    }

    @KafkaListener(topics = KafkaTopics.TOPIC_CLOSE_ORDER_NOTIFY_RETRY,groupId = NotificationAdapterConstants.KAFKA_GROUP_PAYMENT_NOTIFY)
    void closeNotifyRetry(String payload) {
        LOGGER.info("Payload received for closeNotifyRetry: {}", payload);
        kafkaConsumerUtil.preConsume();
        retryCloseNotifyConsumerServiceImpl.process(payload);
    }
}
