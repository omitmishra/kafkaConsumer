package com.paytm.pgplus.notificationadapter.signature;

import com.paytm.pgplus.notificationadapter.signature.encryption.EncryptConstants;
import com.paytm.pgplus.notificationadapter.signature.encryption.Encryption;
import com.paytm.pgplus.notificationadapter.signature.encryption.EncryptionFactory;
import com.paytm.pgplus.notificationadapter.signature.encryption.UtilityConstants;
import org.springframework.stereotype.Service;


import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

@Service
public class SignatureServiceHelper {

    private static class LazyLoader {
        public static final SignatureServiceHelper INSTANCE = new SignatureServiceHelper();
    }

    public static SignatureServiceHelper getInstance() {
        return LazyLoader.INSTANCE;
    }

    private String generateSignature(String key, StringBuilder response) throws Exception {

        String signature = null;
        try {

            String randomNo = CryptoUtils.generateRandomString(UtilityConstants.NO_OF_LAST_CHARS);
            String hash = calculateHash(randomNo,response.toString());
            signature = encrypt(hash, key.getBytes(), EncryptConstants.ALGTHM_TYPE_AES);

            if (signature != null) {
                signature = signature.replaceAll("\r\n", "");
                signature = signature.replaceAll("\r", "");
                signature = signature.replaceAll("\n", "");
            }

        } catch (SecurityException e) {
        	e.printStackTrace();
        }

        return signature;
    }

    public String generateSignature(String key, String body) throws Exception {
        StringBuilder response = new StringBuilder(body);
        response.append(UtilityConstants.PIPE_TEXT);
        return generateSignature(key, response);
    }

    public String generateSignature(String key, TreeMap<String, String> paramap) throws Exception {
        StringBuilder response = getCheckSumString(paramap);
        return generateSignature(key, response);
    }

    private boolean verifySignature(String key, StringBuilder response, String responseSignatureString)
            throws Exception {

        boolean isValidSignature = false;

        String receivedHash = decrypt(responseSignatureString, key.getBytes(), EncryptConstants.ALGTHM_TYPE_AES);
        String randomStr = CryptoUtils.getLastNChars(receivedHash, UtilityConstants.NO_OF_LAST_CHARS);
        String payTmHash = calculateHash(randomStr, response.toString());

        if (null != receivedHash && null != payTmHash) {
            if (receivedHash.equals(payTmHash)) {
                isValidSignature = true;
            }

        }
        return isValidSignature;
    }

    public boolean verifySignature(String key, String body, String responseSignatureString)
            throws Exception {
        StringBuilder response = new StringBuilder(body);
        response.append(UtilityConstants.PIPE_TEXT);
        return verifySignature(key, response, responseSignatureString);
    }

    public boolean verifySignature(String key, TreeMap<String, String> paramap, String responseSignatureString)
            throws Exception {
        StringBuilder response = getCheckSumString(paramap);
        return verifySignature(key, response, responseSignatureString);
    }

    public String encrypt(String toEncrypt, byte[] key, String algorithm) throws Exception {
        Encryption encryption = EncryptionFactory.getEncryptionInstance(algorithm);
        return encryption.encrypt(toEncrypt, key);
    }

    public String decrypt(String toDecrypt, byte[] key, String algorithm) throws Exception {
        Encryption encryption = EncryptionFactory.getEncryptionInstance(algorithm);
        return encryption.decrypt(toDecrypt, key);
    }

    private static String calculateHash(String randomStr, String signatureString) throws Exception {

        String signatureHash = CryptoUtils.getSHA256(signatureString.concat(randomStr));
        signatureHash = signatureHash.concat(randomStr);
        return signatureHash;
    }

    private static StringBuilder getCheckSumString(TreeMap<String, String> paramMap) throws Exception {

        Set<String> keys = paramMap.keySet();

        StringBuilder checkSumStringBuffer = new StringBuilder(UtilityConstants.EMPTY_STRING);

        TreeSet<String> parameterSet = new TreeSet<String>();
        for (String key : keys) {

            if (!(UtilityConstants.CHECKSUMHASH_TEXT.equalsIgnoreCase(key))) {
                parameterSet.add(key);
            }

        }
        for (String paramName : parameterSet) {

            String value = paramMap.get(paramName);
            if (value == null || value.trim().equalsIgnoreCase(UtilityConstants.NULL_TEXT)) {
                value = UtilityConstants.EMPTY_STRING;
            }
            checkSumStringBuffer.append(value).append(UtilityConstants.PIPE_TEXT);

        }
        return checkSumStringBuffer;
    }


}
