package com.paytm.pgplus.notificationadapter.http.exception;

public class AdapterCommonCheckedException extends Exception {

    private static final long serialVersionUID = -3714349158264926392L;

    private Object entity;

    private int responseCode;

    /**
     *
     */
    public AdapterCommonCheckedException() {
        super();
    }

    /**
     * @param message
     */
    public AdapterCommonCheckedException(final String message) {
        super(message);
    }

    /**
     * @param cause
     */
    public AdapterCommonCheckedException(final Throwable cause) {
        super(cause);
    }

    /**
     * @param message
     * @param cause
     */
    public AdapterCommonCheckedException(final String message, final Throwable cause) {
        super(message, cause);
    }

    /**
     * @param message
     * @param cause
     * @param enableSuppression
     * @param writableStackTrace
     */
    public AdapterCommonCheckedException(final String message, final Throwable cause, final boolean enableSuppression,
                                  final boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

    public AdapterCommonCheckedException(final Object entity, final int responseCode) {
        this.responseCode = responseCode;
        this.entity = entity;
    }
}
