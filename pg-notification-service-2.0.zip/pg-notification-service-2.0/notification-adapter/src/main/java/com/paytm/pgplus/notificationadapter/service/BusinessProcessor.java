package com.paytm.pgplus.notificationadapter.service;

public interface BusinessProcessor {
    void process(final String data);
}
