package com.paytm.pgplus.notificationadapter.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.pgplus.notificationadapter.model.Money;
import com.paytm.pgplus.notificationadapter.model.paymentNotify.AmountInfo;
import lombok.Data;

import javax.validation.Valid;
import java.io.Serializable;
import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class OrderPricingInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    @Valid
    private Money orderTotalAmount;
    private List<AmountInfo> amountInfoList;
    private String extendInfo;
}

