package com.paytm.pgplus.notificationadapter.signature.encryption;

public interface EncryptConstants {

    public static final String ALGTHM_TYPE_HASH_SHA_256 = "SHA-256";

    public static final String ALGTHM_TYPE_AES = "AES";
    public static final String ALGTHM_TYPE_RSA = "RSA";

    public static final String ALGTHM_CBC_PAD_AES = "AES/CBC/PKCS5PADDING";
    public static final String CIPHER_RSA_ECB_OAEP = "RSA/ECB/OAEPWithSHA1AndMGF1Padding";
    public static final String CIPHER_AES_CTR_NO_PADDING = "AES/CTR/NoPadding";
    public static final String HMAC_ALGORITHM_512 = "HmacSHA512";

    public static final String ALGTHM_PROVIDER_JCE = "SunJCE";

    public static final String PROVIDER_BC = "BC";

    public static final int NONCE_SIZE_64_BITS = 64;

}
