package com.paytm.pgplus.notificationadapter.model.paymentNotify;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.pgplus.notificationadapter.model.Money;
import lombok.Data;

import javax.validation.Valid;
import java.io.Serializable;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class AmountInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    @Valid
    private Money amount;
    private String direction;
    private String amountType;

}

