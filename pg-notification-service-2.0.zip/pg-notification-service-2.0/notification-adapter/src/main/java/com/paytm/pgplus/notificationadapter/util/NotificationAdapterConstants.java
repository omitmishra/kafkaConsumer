package com.paytm.pgplus.notificationadapter.util;


public class NotificationAdapterConstants {


    //kafka group
    public static final String KAFKA_GROUP_PAYMENT_NOTIFY = "pgp-nqh-payment-notify";
    public static final String KAFKA_GROUP_CLOSE_NOTIFY = "pgp-nqh-close-notify";


    public static class Configurations {

        public static final String PROPERTY_FILE_LOCATION = "/etc/appconf/kafka-client.properties";
        public static final String SIGN_PROPERTY_FILE_LOCATION = "/etc/appconf/config.properties";
//        public static final String MIN_POOL_SIZE = "min.pool.size";
//        public static final String MAX_POOL_SIZE = "max.pool.size";
//        public static final String KEEP_ALIVE_TIME_SECONDS = "keep.alive.time";
//        public static final  String  SHUTDOWN_WAIT_TIME_SECONDS= "shutdown.wait.time";
//
//
//        public static final  int DEFAULT_MIN_POOL_SIZE= 0;
//
//        public static final  int DEFAULT_MAX_POOL_SIZE= 0;
//
//        public static final  int DEFAULT_KEEP_ALIVE_TIME_SECONDS= 0;
//
//        public static final  int DEFAULT_SHUT_DOWN_TIME_SECONDS= 0;

    }

}
