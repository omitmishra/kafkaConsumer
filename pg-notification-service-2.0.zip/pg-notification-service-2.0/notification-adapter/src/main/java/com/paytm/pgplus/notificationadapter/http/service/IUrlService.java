package com.paytm.pgplus.notificationadapter.http.service;

import com.paytm.pgplus.notificationadapter.http.enums.ServiceUrl;

public interface IUrlService {
    String getUrl(ServiceUrl serviceUrl);
}
