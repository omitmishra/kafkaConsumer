package com.paytm.pgplus.notificationadapter.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.io.Serializable;


@JsonIgnoreProperties(ignoreUnknown = true)
public class NotificationRequestPayload<H, B> implements Serializable {

    /**
     * Serial version uid
     */
    private static final long serialVersionUID = -3026225570859769831L;

    @NotNull(message = "{notnull}")
    @Valid
    H head;

    @NotNull(message = "{notnull}")
    @Valid
    B body;

    /**
     * @return the head
     */
    public H getHead() {
        return head;
    }

    /**
     * @param head
     *            the head to set
     */
    public void setHead(H head) {
        this.head = head;
    }

    /**
     * @return the body
     */
    public B getBody() {
        return body;
    }

    /**
     * @param body
     *            the body to set
     */
    public void setBody(B body) {
        this.body = body;
    }
}
