package com.paytm.pgplus.notificationadapter.signature.encryption;

import org.apache.commons.codec.binary.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class AesEncryption implements Encryption {

    private final byte[] ivParamBytes = {'@', '@', '@', '@',
            '&', '&', '&', '&',
            '#', '#', '#', '#',
            '$', '$', '$', '$'};

    @Override
    public String encrypt(String toEncrypt, byte[] key) throws Exception {
        String encryptedValue = "";
        Cipher cipher = Cipher.getInstance(EncryptConstants.ALGTHM_CBC_PAD_AES, EncryptConstants.ALGTHM_PROVIDER_JCE);
        cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(key, EncryptConstants.ALGTHM_TYPE_AES), new IvParameterSpec(ivParamBytes));
        encryptedValue = Base64.encodeBase64String(cipher.doFinal(toEncrypt.getBytes()));
        return encryptedValue;
    }

    @Override
    public String decrypt(String toDecrypt, byte[] key) throws Exception {
        String decryptedValue = "";
        Cipher cipher = Cipher.getInstance(EncryptConstants.ALGTHM_CBC_PAD_AES, EncryptConstants.ALGTHM_PROVIDER_JCE);
        cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key, EncryptConstants.ALGTHM_TYPE_AES), new IvParameterSpec(ivParamBytes));
        decryptedValue = new String(cipher.doFinal(Base64.decodeBase64(toDecrypt)));
        return decryptedValue;
    }


}
