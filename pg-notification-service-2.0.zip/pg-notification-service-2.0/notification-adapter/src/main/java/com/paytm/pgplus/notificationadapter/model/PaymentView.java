package com.paytm.pgplus.notificationadapter.model;


import java.io.Serializable;
import java.util.Arrays;
import java.util.Collections;
import java.util.Map;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.paytm.pgplus.notificationadapter.helper.JsonMapper;
import com.paytm.pgplus.notificationadapter.model.paymentNotify.PayOptionInfo;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.validator.constraints.NotBlank;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PaymentView implements Serializable {

    /**
     * Serial version UID
     */
    private static final long serialVersionUID = 1234794330008862704L;

    @NotBlank(message = "{notblank}")
    private String cashierRequestId;

    @NotBlank(message = "{notblank}")
    private String paidTime;

    private Boolean revoked;

    private String payRequestExtendInfo;

    private String pwpCategory;

    private String extendInfo;

    @Valid
    private PayOptionInfo[] payOptionInfos;

    public String getPayRequestExtendInfo() {
        return payRequestExtendInfo;
    }

    public void setPayRequestExtendInfo(String payRequestExtendInfo) {
        this.payRequestExtendInfo = payRequestExtendInfo;
    }

    public String getExtendInfo() {
        return extendInfo;
    }

    public void setExtendInfo(String extendInfo) {
        this.extendInfo = extendInfo;
    }

    /**
     * @return the cashierRequestId
     */
    public String getCashierRequestId() {
        return cashierRequestId;
    }

    /**
     * @param cashierRequestId
     *            the cashierRequestId to set
     */
    public void setCashierRequestId(String cashierRequestId) {
        this.cashierRequestId = cashierRequestId;
    }

    /**
     * @return the paidTime
     */
    public String getPaidTime() {
        return paidTime;
    }

    /**
     * @param paidTime
     *            the paidTime to set
     */
    public void setPaidTime(String paidTime) {
        this.paidTime = paidTime;
    }

    /**
     * @return the payOptionInfos
     */
    public PayOptionInfo[] getPayOptionInfos() {
        return payOptionInfos;
    }

    /**
     * @param payOptionInfos
     *            the payOptionInfos to set
     */
    public void setPayOptionInfos(PayOptionInfo[] payOptionInfos) {
        this.payOptionInfos = payOptionInfos;
    }

    @SuppressWarnings("unchecked")
    public Map<String, String> getExtendInfoMap() {
        try {
            if (StringUtils.isNotBlank(extendInfo)) {
                return JsonMapper.mapJsonToObject(extendInfo, Map.class);
            }
        } catch (final JsonProcessingException e) {
        }
        return Collections.emptyMap();
    }

    @SuppressWarnings("unchecked")
    public Map<String, String> getPayRequestExtendInfoMap() {
        try {
            if (StringUtils.isNotBlank(payRequestExtendInfo)) {
                return JsonMapper.mapJsonToObject(payRequestExtendInfo, Map.class);
            }
        } catch (final JsonProcessingException e) {
        }
        return Collections.emptyMap();
    }

    public Boolean getRevoked() {
        return revoked;
    }

    public void setRevoked(Boolean revoked) {
        this.revoked = revoked;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("PaymentView [cashierRequestId=").append(cashierRequestId).append(", paidTime=")
                .append(paidTime).append(", payRequestExtendInfo=").append(payRequestExtendInfo).append(", revoked=")
                .append(revoked).append(", extendInfo=").append(extendInfo).append(", payOptionInfos=")
                .append(Arrays.toString(payOptionInfos)).append("]");
        return builder.toString();
    }

    public String getPwpCategory() {
        return pwpCategory;
    }

    public void setPwpCategory(String pwpCategory) {
        this.pwpCategory = pwpCategory;
    }
}