package com.paytm.pgplus.notificationadapter.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.pgplus.notificationadapter.model.Money;

import java.io.Serializable;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SplitCommandInfo implements Serializable {

    private static final long serialVersionUID = 3794889079183136936L;

    private String splitMethod;
    private String targetMerchantId;
    private String paytmMerchantId;
    private Money amount;
    private String percentage;
    private String extendInfo;

    public String getSplitMethod() {
        return splitMethod;
    }

    public void setSplitMethod(String splitMethod) {
        this.splitMethod = splitMethod;
    }

    public String getTargetMerchantId() {
        return targetMerchantId;
    }

    public void setTargetMerchantId(String targetMerchantId) {
        this.targetMerchantId = targetMerchantId;
    }

    public String getPaytmMerchantId() {
        return paytmMerchantId;
    }

    public void setPaytmMerchantId(String paytmMerchantId) {
        this.paytmMerchantId = paytmMerchantId;
    }

    public Money getAmount() {
        return amount;
    }

    public void setAmount(Money amount) {
        this.amount = amount;
    }

    public String getPercentage() {
        return percentage;
    }

    public void setPercentage(String percentage) {
        this.percentage = percentage;
    }

    public String getExtendInfo() {
        return extendInfo;
    }

    public void setExtendInfo(String extendInfo) {
        this.extendInfo = extendInfo;
    }

    @Override
    public String toString() {
        return "SplitCommandInfo{" + "splitMethod='" + splitMethod + '\'' + ", targetMerchantId='" + targetMerchantId
                + '\'' + ", paytmMerchantId='" + paytmMerchantId + '\'' + ", amount=" + amount + ", percentage='"
                + percentage + '\'' + ", extendInfo='" + extendInfo + '\'' + '}';
    }
}

