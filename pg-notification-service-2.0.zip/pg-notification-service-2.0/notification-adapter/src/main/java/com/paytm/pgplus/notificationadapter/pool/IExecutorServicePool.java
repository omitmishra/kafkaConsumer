package com.paytm.pgplus.notificationadapter.pool;

import java.util.concurrent.ExecutionException;

public interface IExecutorServicePool {

    void submitJob(Runnable task) throws InterruptedException, ExecutionException;

    /**
     * @throws InterruptedException
     */
    void shutDown() throws InterruptedException;
}
