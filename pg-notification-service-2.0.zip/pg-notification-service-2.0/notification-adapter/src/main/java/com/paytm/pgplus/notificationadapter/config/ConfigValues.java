package com.paytm.pgplus.notificationadapter.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;

import java.io.*;
import java.util.Properties;

import static com.paytm.pgplus.notificationadapter.util.NotificationAdapterConstants.Configurations.SIGN_PROPERTY_FILE_LOCATION;

@Configuration
public class ConfigValues {

    private static final Logger LOGGER = LoggerFactory.getLogger("ConfigValues.class");
    private  static Properties props = null;

    static {
        // Initialize Project configurations
        loadConfigValues();
    }


    public static Properties getProperties() {
        return props;
    }

    private static void loadConfigValues() {
            if (props == null) {
                synchronized (KafkaClientConfig.class) {
                    if (props == null) {
                        InputStream inStream = null;
                        try {
                            props = new Properties();
                            inStream = new FileInputStream(new File(SIGN_PROPERTY_FILE_LOCATION));
                            props.load(inStream);
                            LOGGER.info("Initialized Project configuration from file : {}", SIGN_PROPERTY_FILE_LOCATION);
                        } catch (final Exception ex) {
                            LOGGER.error("Exception in reading property file : " + SIGN_PROPERTY_FILE_LOCATION, ex);
                            System.exit(0);
                        } finally {
                            if (inStream != null) {
                                try {
                                    inStream.close();
                                } catch (final IOException ex) {
                                    LOGGER.error("Exception in closing file stream for : " + SIGN_PROPERTY_FILE_LOCATION, ex);
                                    System.exit(0);
                                }
                            }
                        }
                    }
                }
            }
            LOGGER.debug("props : {}", props);
        }

    }

