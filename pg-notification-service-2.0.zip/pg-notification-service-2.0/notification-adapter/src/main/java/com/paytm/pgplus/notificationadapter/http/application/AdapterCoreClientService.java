package com.paytm.pgplus.notificationadapter.http.application;

import com.paytm.pgplus.notificationadapter.config.ApplicationConfig;
import com.paytm.pgplus.notificationadapter.config.KafkaProducer;
import com.paytm.pgplus.notificationadapter.http.enums.ServiceUrl;
import com.paytm.pgplus.notificationadapter.http.exception.AdapterCommonUnCheckedException;
import com.paytm.pgplus.notificationadapter.http.exception.AdapterCoreClientException;
import com.paytm.pgplus.notificationadapter.http.service.IUrlService;
import com.paytm.pgplus.notificationadapter.topics.KafkaTopics;
import lombok.SneakyThrows;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.util.retry.Retry;

import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.Objects;

@Service

public class AdapterCoreClientService {

    private static final Logger log= LoggerFactory.getLogger(AdapterCoreClientService.class);

    @Autowired
    private WebClient webClient;

    @Autowired
    IUrlService urlService;

    @Autowired
    KafkaProducer kafkaProducer;

    @Autowired
    ApplicationConfig applicationConfig;

    public <S,T> void executePost(S request, ServiceUrl serviceUrl, Class<T> responseClass,final String topic) throws AdapterCoreClientException {
        try{
            String url = urlService.getUrl(serviceUrl);
            log.info("Request received in executePost with payload:{}",request);
            doPost(request, url, responseClass,topic);
        }catch (Exception e){
            log.error("Some error occurred while sending the post request ,exception : {}", e);

        }

    }

    private <T> void verifyResponse(LinkedHashMap response) {
        LinkedHashMap bodyMap=null;
        LinkedHashMap responseMap=null;
        LinkedHashMap resultInfo=null;
            try {
                if (response.get("response")!=null )  {
                    responseMap=(LinkedHashMap)response.get("response");
                    if(responseMap.get("body")!=null)
                    bodyMap= (LinkedHashMap) responseMap.get("body");
                    if(bodyMap.get("resultInfo")!=null)
                    resultInfo= (LinkedHashMap) bodyMap.get("resultInfo");
                if (resultInfo !=null && resultInfo.get("resultStatus").toString().equalsIgnoreCase("S") && resultInfo.get("resultCode").toString().equalsIgnoreCase("SUCCESS")) {

                    log.info("resultCode   is    {} is : {}", resultInfo.get("resultCode"), resultInfo.get("resultMsg"));

                }
                }
            }catch (Exception e){
                log.error("Failed to verify response : {} received from pg-proxy-notification, exception : {}",response.toString(),e);
            }

    }

   // @SneakyThrows
    public <S,T>  void doPost(S request, String url, Class<T> responseClass,final String topic) throws AdapterCoreClientException {
        final Long startTime = System.currentTimeMillis();
        int retryCount=3;
        if(topic.equals(KafkaTopics.TOPIC_PAYMENT_NOTIFY_RETRY) || topic.equals(KafkaTopics.TOPIC_CLOSE_ORDER_NOTIFY_RETRY)){
            retryCount= applicationConfig.getRetryCount();
        }

        try {
                    webClient.post()
                    .uri(url)
                    .accept(MediaType.APPLICATION_JSON)
                    .body(Mono.just(request), request.getClass())
                    .retrieve()
                    .onStatus(HttpStatus::isError, error -> {
                                if (error.statusCode().is4xxClientError())
                                    log.error("Url not found, {}", url);
                                else log.error("Server error returned for url {}, {}", url, error);
                                return Mono.just(new AdapterCoreClientException(Objects.requireNonNull(error.toString())));

                            }
                    )
                    .bodyToMono(Object.class).log()
                    .retryWhen(Retry.backoff(retryCount, Duration.ofSeconds(2))
                            .filter(throwable -> throwable instanceof Exception)
                            .onRetryExhaustedThrow((retryBackoffSpec, retrySignal) -> {
                                if(topic.equals(KafkaTopics.TOPIC_CLOSE_ORDER_NOTIFY_RETRY) || topic.equals(KafkaTopics.TOPIC_PAYMENT_NOTIFY_RETRY)){
                                    log.error("External Service failed to process after max retries, error code : {}",HttpStatus.SERVICE_UNAVAILABLE.value());
                                }else {
                                     pushPayloadToRetryTopic(request, topic);
                                }
                                return  new AdapterCommonUnCheckedException("something went wrong: {}"+request);
                            }))
                    .subscribe(response -> {
                            if(response!=null){

                                log.info("Time taken to receive response from pg-proxy : {}",System.currentTimeMillis()-startTime);
                                log.info(" receive response :{}", response.toString());
                                verifyResponse((LinkedHashMap) response);

                            }else{
                                log.warn("Response received from pg-proxy-notification is null!");
                            }
                    }) ;

        }
        catch (Exception e){

            throw new AdapterCoreClientException(e.getMessage());
        }
    }

    public <S> void pushPayloadToRetryTopic(S request,final String topic) {
        String topicToPush=null;
        switch (topic){
            case KafkaTopics.TOPIC_PAYMENT_NOTIFY:
                topicToPush=KafkaTopics.TOPIC_PAYMENT_NOTIFY_RETRY;
                break;
            case KafkaTopics.TOPIC_CLOSE_ORDER_NOTIFY:
                topicToPush=KafkaTopics.TOPIC_CLOSE_ORDER_NOTIFY_RETRY;
                break;
            default:
                topicToPush=null;
                break;
        }
        try {
            String tempRequest=(String)request;
            if(!StringUtils.isBlank(topicToPush)){
                kafkaProducer.publishMessage(topicToPush,tempRequest);
                log.info("Payload:{} sent for pushing to kafka retry topic :{}",tempRequest,topicToPush);
            }else{
                log.warn("Retry topic not found for topic:{}",topic);
            }

        }
        catch (Exception e){
            log.error("Some error occurred in pushing payload :{} to kafka topic :{}",request,KafkaTopics.TOPIC_CLOSE_ORDER_NOTIFY_RETRY);
        }
    }
}
