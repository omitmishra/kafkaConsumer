package com.paytm.pgplus.notificationadapter.healthcheck;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.config.KafkaListenerEndpointRegistry;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.File;
import java.io.IOException;

@RestController
@RequestMapping("/healthCheck")
public class HealthCheckService {

    Logger LOGGER = LoggerFactory.getLogger(HealthCheckService.class);

    @Autowired
    KafkaListenerEndpointRegistry kafkaListenerEndpointRegistry;

    @GetMapping("/checkKafkaConsumerState")
    public ResponseEntity<String> checkKafkaConsumerState() throws IOException {

        LOGGER.info("Starting to check KafkaListener state");

        final File healthCheckFile = new File("/adaptor/healthcheck/healthcheck.txt");
        if (healthCheckFile.exists() && !healthCheckFile.isDirectory()) {
            if (!kafkaListenerEndpointRegistry.isRunning()) {
                LOGGER.warn("Found healthcheck.txt, Starting kafkaListenerEndpointRegistry!!");
                kafkaListenerEndpointRegistry.start();
                LOGGER.warn("Started kafkaListenerEndpointRegistry!!");
            } else {
                LOGGER.info("Healthcheck found, Kafka container is already active..");
            }
            return new ResponseEntity<String>("SUCCESS", HttpStatus.OK);
        } else {
            if (kafkaListenerEndpointRegistry.isRunning()) {
                LOGGER.warn("Stopping kafkaListenerEndpointRegistry!!");
                kafkaListenerEndpointRegistry.stop();
                LOGGER.warn("Stopped kafkaListenerEndpointRegistry!!");
            } else {
                LOGGER.info("Healthcheck not found, Kafka container is already deactive..");
            }
            return new ResponseEntity<String>("FAILED", HttpStatus.NOT_FOUND);
        }
    }
}



