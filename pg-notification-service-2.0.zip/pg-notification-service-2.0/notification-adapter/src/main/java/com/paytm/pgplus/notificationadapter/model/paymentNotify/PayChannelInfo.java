package com.paytm.pgplus.notificationadapter.model.paymentNotify;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;

import java.io.Serializable;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PayChannelInfo implements Serializable {

    private static final long serialVersionUID = 4890056997403631604L;
    // @NotBlank(message = "{notblank}")
    private String virtualPaymentAddr;

    // @NotBlank(message = "{notblank}")
    private String payerVpaCustomerId;

    private String payOption;

    public String getVirtualPaymentAddr() {
        return virtualPaymentAddr;
    }

    public void setVirtualPaymentAddr(String virtualPaymentAddr) {
        this.virtualPaymentAddr = virtualPaymentAddr;
    }

    public String getPayerVpaCustomerId() {
        return payerVpaCustomerId;
    }

    public void setPayerVpaCustomerId(String payerVpaCustomerId) {
        this.payerVpaCustomerId = payerVpaCustomerId;
    }

    public String getPayOption() {
        return payOption;
    }

    public void setPayOption(String payOption) {
        this.payOption = payOption;
    }

    @Override
    public String toString() {
        return "PayChannelInfo{" + "virtualPaymentAddr='" + virtualPaymentAddr + '\'' + ", payerVpaCustomerId='"
                + payerVpaCustomerId + payOption + '\'' + ", payOption= }'";
    }
}

