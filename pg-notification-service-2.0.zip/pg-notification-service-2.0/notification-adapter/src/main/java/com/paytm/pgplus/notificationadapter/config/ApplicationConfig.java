package com.paytm.pgplus.notificationadapter.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;


@Configuration
public class ApplicationConfig {
    private static final Logger LOGGER = LoggerFactory.getLogger(ApplicationConfig.class);


    @Value("${min.pool.size:0}")
    private int minPoolSize;

    @Value("${max.pool.size:0}")
    private int maxPoolSize;

    @Value("${keep.alive.time:0}")
    private static int keepAliveTimeInMillis;

    @Value("${shutdown.wait.time:0}")
    private int appShutDownTimeInMillis;

    @Value("${retry.count:0}")
    private int retryCount;


    public int getMinPoolSize() {
        return minPoolSize;
    }

    public int getMaxPoolSize() {
        return maxPoolSize;
    }

    public int getKeepAliveTimeInMillis() {
        return keepAliveTimeInMillis;
    }

    public int getAppShutDownTimeInMillis() {
        return appShutDownTimeInMillis;
    }

    public int getRetryCount() {
        return retryCount;
    }


}
