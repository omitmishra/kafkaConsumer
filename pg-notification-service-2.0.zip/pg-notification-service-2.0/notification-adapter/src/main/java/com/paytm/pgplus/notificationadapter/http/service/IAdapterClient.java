package com.paytm.pgplus.notificationadapter.http.service;

import com.paytm.pgplus.notificationadapter.http.exception.AdapterCommonCheckedException;
import com.paytm.pgplus.notificationadapter.http.exception.AdapterCommonUnCheckedException;
import com.paytm.pgplus.notificationadapter.http.exception.AdapterCoreClientException;
import com.paytm.pgplus.notificationadapter.model.NotificationRequestPayload;
import org.springframework.http.ResponseEntity;

import javax.ws.rs.core.Response;

public interface IAdapterClient {

    public void  processPaymentNotify(String payload)
            throws AdapterCommonCheckedException, AdapterCommonUnCheckedException, AdapterCoreClientException;

    public void  processRetryPaymentNotify(String payload) throws AdapterCoreClientException ,AdapterCommonUnCheckedException;

    public void  processRetryCloseNotify(String payload) throws AdapterCoreClientException ,AdapterCommonUnCheckedException;

    public void  processCloseNotify(String payload) throws AdapterCoreClientException ,AdapterCommonUnCheckedException;
    }
