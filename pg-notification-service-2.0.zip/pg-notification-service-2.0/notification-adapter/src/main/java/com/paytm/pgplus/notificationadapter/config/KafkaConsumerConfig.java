package com.paytm.pgplus.notificationadapter.config;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.protocol.types.Field;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;

import java.util.HashMap;
import java.util.Map;

@EnableKafka
@Configuration
public class KafkaConsumerConfig {

    @Bean
    public ConsumerFactory<String, String> consumerFactory() {
        Map<String, Object> props = new HashMap<>();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, KafkaClientConfig.getProperty(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG));
        props.put(ConsumerConfig.GROUP_ID_CONFIG, KafkaClientConfig.getProperty(ConsumerConfig.GROUP_ID_CONFIG));
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        // Set this property, if auto commit should happen.
        props.put("enable.auto.commit",KafkaClientConfig.getProperty(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG));

        // Auto commit interval, kafka would commit offset at this interval.
        props.put("auto.commit.interval.ms", KafkaClientConfig.getProperty(ConsumerConfig.AUTO_COMMIT_INTERVAL_MS_CONFIG));

        // This is how to control number of records being read in each poll
        props.put("max.partition.fetch.bytes", KafkaClientConfig.getProperty(ConsumerConfig.MAX_PARTITION_FETCH_BYTES_CONFIG));

        // Set this if you want to always read from beginning.
        // props.put("auto.offset.reset", "earliest");

        props.put("heartbeat.interval.ms", KafkaClientConfig.getProperty(ConsumerConfig.HEARTBEAT_INTERVAL_MS_CONFIG));
        props.put("session.timeout.ms", KafkaClientConfig.getProperty(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG));
        return new DefaultKafkaConsumerFactory<>(props);
    }

    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, String> kafkaListenerContainerFactory() {
        ConcurrentKafkaListenerContainerFactory<String, String> factory = new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(consumerFactory());

        //factory.set
        return factory;
    }
}