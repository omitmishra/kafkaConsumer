package com.paytm.pgplus.notificationadapter.config;

import lombok.SneakyThrows;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Component;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.concurrent.TimeUnit;

@Component
@EnableKafka
@RestController
public class KafkaProducer {

  @Autowired
  @Qualifier("kafkaProducerTemplate")
  private KafkaTemplate<String, String> kafkaTemplate;

  private static final Logger log= LoggerFactory.getLogger(KafkaProducer.class);

  /**
   * @param topic the topic
   * @param unifiedData the unified data
   */
  @SneakyThrows
  public void publishMessage(String topic, String unifiedData) {
    try {
      kafkaTemplate.send(topic, unifiedData);
      log.info("SendingMessage" + " [" + topic + "][" + unifiedData + "]");

    } catch (Exception exc) {
      log.error("Error while publishing", exc);
      throw exc;
    }
  }

  /***
   * message publisher
   * @param record
   */
  public void publishMessage(ProducerRecord record) {
    try {

      kafkaTemplate.send(record).get(2L, TimeUnit.SECONDS);
      log.info("SendingMessage" + " [" + record + "]");
    } catch (Exception exc) {
      log.error("Error while publishing", exc);
    }
  }

  @GetMapping("/publish")
  public void publishMessageV2( ) {
    try {
      // String s="{\"acquirementId\":\"20211118111212800110168368067012651\",\"merchantTransId\":\"202111181535060046\",\"orderAmount\":{\"cent\":\"123\",\"currency\":\"INR\"},\"merchantId\":\"Mercha1212121212\",\"productCode\":\"Iphone123\",\"contractId\":\"contract1212\",\"createOrderTime\":\"12:30\",\"buyerInfo\":{\"userId\":\"user1\",\"externalUserId\":\"userOut\",\"externalUserType\":\"Person\",\"nickname\":\"lallu\"},\"closedTime\":\"1:00AM\",\"closeResult\":{\"resultStatus\":\"SD\",\"resultCodeId\":\"SAD123\",\"resultCode\":\"sedlyf\"},\"paymentViews\":[{\"cashierRequestId\":\"cash\",\"paidTime\":\"neverPaid\",\"payOptionInfos\":[{\"payMethod\":\"BALANCE\",\"payAmount\":{\"cent\":\"123\",\"currency\":\"INR\"},\"transAmount\":{\"cent\":\"123\",\"currency\":\"INR\"},\"assetType\":\"noAsset\",\"extendInfo\":\"\",\"payOptionBillExtendInfo\":\"{\\\"totalTxnAmount\\\":\\\"100\\\",\\\"checkoutJsAppInvokePayment\\\":\\\"false\\\",\\\"CUST_ID\\\":\\\"cid\\\",\\\"issuingBankName\\\":\\\"HDFC\\\",\\\"preDebitRenewal\\\":\\\"false\\\",\\\"graceDays\\\":\\\"0\\\",\\\"TXN_TOKEN\\\":\\\"48c03bb2f7f74cebaf4d8f49647b83b71637654307523\\\",\\\"isEnhancedNative\\\":\\\"false\\\",\\\"pushDataToDynamicQR\\\":\\\"false\\\",\\\"communicationManager\\\":\\\"false\\\",\\\"merchantName\\\":\\\"storedCardNo\\\",\\\"isMerchantLimitUpdatedForPay\\\":\\\"false\\\",\\\"prepaidCard\\\":\\\"false\\\",\\\"mccCode\\\":\\\"BFSI\\\",\\\"linkBasedInvoicePayment\\\":\\\"false\\\",\\\"topupAndPay\\\":\\\"false\\\",\\\"isMerchantLimitEnabledForPay\\\":\\\"false\\\",\\\"clientIP\\\":\\\"127.0.0.1\\\",\\\"paymodeIdentifier\\\":\\\"33\\\",\\\"peonURL\\\":\\\"https://pgp-automation.paytm.in/mockbank/MerchantSite/bankResponse\\\",\\\"virtualPaymentAddr\\\":\\\"certfcn@paytm\\\",\\\"alipayMerchantId\\\":\\\"111\\\",\\\"merchantOnPaytm\\\":\\\"false\\\",\\\"website\\\":\\\"retail\\\",\\\"callBackURL\\\":\\\"https://pgp-automation.paytm.in/mockbank/MerchantSite/bankResponse\\\",\\\"requestType\\\":\\\"NATIVE\\\",\\\"merchantLimitEnabled\\\":\\\"false\\\",\\\"fromAoaMerchant\\\":\\\"false\\\",\\\"merchantLimitUpdated\\\":\\\"false\\\",\\\"corporateCard\\\":\\\"false\\\",\\\"subsRenewOrderAlreadyCreated\\\":\\\"false\\\",\\\"linkBasedNonInvoicePayment\\\":\\\"false\\\",\\\"offlineFlow\\\":\\\"false\\\",\\\"productCode\\\":\\\"51051000100000000001\\\",\\\"merchantTransId\\\":\\\"AJ001TEST77\\\",\\\"custID\\\":\\\"cid\\\",\\\"paytmMerchantId\\\":\\\"216820000000269278303\\\",\\\"autoRenewal\\\":\\\"false\\\",\\\"paymentRequestFlow\\\":\\\"nativeJsonRequest\\\",\\\"autoRetry\\\":\\\"false\\\",\\\"cardTokenRequired\\\":\\\"false\\\",\\\"enhancedNative\\\":\\\"false\\\"}\",\"payChannelInfo\":{\"virtualPaymentAddr\":\"abc\",\"payOption\":\"noOption\",\"payerVpaCustomerId\":\"lol\"}}],\"payRequestExtendInfo\":\"\",\"extendInfo\":\"\",\"revoked\":false}],\"orderExtendInfo\":\"\",\"acquireMode\":\"LOLMODE\",\"closeReason\":\"GOT_BORED\",\"closeSource\":\"NO_ONE\"}";
      String s="{\"acquirementId\":\"20211118111212800110168368067012651\",\"merchantTransId\":\"202111181535060046\",\"orderAmount\":{\"cent\":\"123\",\"currency\":\"INR\"},\"merchantId\":\"Mercha1212121212\",\"productCode\":\"Iphone123\",\"contractId\":\"contract1212\",\"createOrderTime\":\"12:30\",\"buyerInfo\":{\"userId\":\"user1\",\"externalUserId\":\"userOut\",\"externalUserType\":\"Person\",\"nickname\":\"lallu\"},\"acquireMode\":\"Online\",\"orderStatus\":\"Success\",\"payId\":\"PAY23DF\",\"sellerInfo\":{\"userId\":\"user1\",\"externalUserId\":\"userOut\",\"externalUserType\":\"Person\",\"nickname\":\"lallu\"},\"createdTime\":\"12:30PM\",\"paidTime\":\"12:36PM\",\"pdEventCode\":\"123E\",\"paymentView\":{\"cashierRequestId\":\"cash\",\"paidTime\":\"12:36PM\",\"payOptionInfos\":[{\"payMethod\":\"BALANCE\",\"payAmount\":{\"cent\":\"123\",\"currency\":\"INR\"},\"transAmount\":{\"cent\":\"123\",\"currency\":\"INR\"},\"assetType\":\"noAsset\",\"extendInfo\":\"{\\\"totalTxnAmount\\\":\\\"100\\\",\\\"checkoutJsAppInvokePayment\\\":\\\"false\\\",\\\"CUST_ID\\\":\\\"cid\\\",\\\"issuingBankName\\\":\\\"HDFC\\\",\\\"preDebitRenewal\\\":\\\"false\\\",\\\"graceDays\\\":\\\"0\\\",\\\"TXN_TOKEN\\\":\\\"48c03bb2f7f74cebaf4d8f49647b83b71637654307523\\\",\\\"isEnhancedNative\\\":\\\"false\\\",\\\"pushDataToDynamicQR\\\":\\\"false\\\",\\\"communicationManager\\\":\\\"false\\\",\\\"merchantName\\\":\\\"storedCardNo\\\",\\\"isMerchantLimitUpdatedForPay\\\":\\\"false\\\",\\\"prepaidCard\\\":\\\"false\\\",\\\"mccCode\\\":\\\"BFSI\\\",\\\"linkBasedInvoicePayment\\\":\\\"false\\\",\\\"topupAndPay\\\":\\\"false\\\",\\\"isMerchantLimitEnabledForPay\\\":\\\"false\\\",\\\"clientIP\\\":\\\"127.0.0.1\\\",\\\"paymodeIdentifier\\\":\\\"33\\\",\\\"peonURL\\\":\\\"https://pgp-automation.paytm.in/mockbank/MerchantSite/bankResponse\\\",\\\"virtualPaymentAddr\\\":\\\"certfcn@paytm\\\",\\\"alipayMerchantId\\\":\\\"111\\\",\\\"merchantOnPaytm\\\":\\\"false\\\",\\\"website\\\":\\\"retail\\\",\\\"callBackURL\\\":\\\"https://pgp-automation.paytm.in/mockbank/MerchantSite/bankResponse\\\",\\\"requestType\\\":\\\"NATIVE\\\",\\\"merchantLimitEnabled\\\":\\\"false\\\",\\\"fromAoaMerchant\\\":\\\"false\\\",\\\"merchantLimitUpdated\\\":\\\"false\\\",\\\"corporateCard\\\":\\\"false\\\",\\\"subsRenewOrderAlreadyCreated\\\":\\\"false\\\",\\\"linkBasedNonInvoicePayment\\\":\\\"false\\\",\\\"offlineFlow\\\":\\\"false\\\",\\\"productCode\\\":\\\"51051000100000000001\\\",\\\"merchantTransId\\\":\\\"AJ001TEST77\\\",\\\"custID\\\":\\\"cid\\\",\\\"paytmMerchantId\\\":\\\"216820000000269278303\\\",\\\"autoRenewal\\\":\\\"false\\\",\\\"paymentRequestFlow\\\":\\\"nativeJsonRequest\\\",\\\"autoRetry\\\":\\\"false\\\",\\\"cardTokenRequired\\\":\\\"false\\\",\\\"enhancedNative\\\":\\\"false\\\"}\",\"payOptionBillExtendInfo\":\"\",\"payChannelInfo\":{\"virtualPaymentAddr\":\"abc\",\"payOption\":\"noOption\",\"payerVpaCustomerId\":\"lol\"}}],\"payRequestExtendInfo\":\"\",\"extendInfo\":\"\",\"revoked\":false},\"orderExtendInfo\":\"\",\"extendInfo\":\"\",\"merchantName\":\"Uber\",\"userMobileNo\":\"7689678904\",\"payResult\":{\"resultStatus\":\"S\",\"resultCodeId\":\"12445\",\"resultCode\":\"xx\",\"resultMsg\":\"NA\"},\"timeoutExtendInfo\":\"\"}";
      // kafkaTemplate.send("TOPIC_CLOSE_ORDER_NOTIFY",s);
      String test="{\"acquirementId\":\"20211208015706675421847147249664\",\"merchantTransId\":\"31423tresa2122r2398332r36\",\"orderAmount\":{\"cent\":100,\"currency\":\"INR\",\"currencyValue\":\"356\",\"currencyCode\":\"INR\",\"amount\":1.00,\"centFactor\":100},\"merchantId\":\"216820000000269278303\",\"productCode\":\"51051000100000000001\",\"contractId\":\"2000021951051010016800013034300\",\"createOrderTime\":\"2021-12-08T19:25:16.684+05:30\",\"buyerInfo\":{\"userId\":\"123\",\"externalUserId\":\"cid\",\"externalUserType\":\"MERCHANT\",\"nickname\":\"\"},\"acquireMode\":\"DIRECTPAY\",\"orderStatus\":\"SUCCESS\",\"payId\":\"2134354253212345134\",\"createdTime\":\"2021-12-08T19:25:16.684+05:30\",\"paidTime\":\"2021-12-08T19:25:21.719+05:30\",\"pdEventCode\":\"12128004\",\"paymentView\":{\"cashierRequestId\":\"23456745352345263\",\"paidTime\":\"2021-12-08T19:25:21.719+05:30\",\"payOptionInfos\":[{\"payMethod\":\"UPI\",\"payAmount\":{\"cent\":100,\"currency\":\"INR\",\"currencyValue\":\"356\",\"currencyCode\":\"INR\",\"amount\":1.00,\"centFactor\":100},\"transAmount\":{\"cent\":100,\"currency\":\"INR\",\"currencyValue\":\"356\",\"currencyCode\":\"INR\",\"amount\":1.00,\"centFactor\":100},\"assetType\":\"SAMPLE_ASSET_TYPE\",\"extendInfo\":\"{\\\"totalTxnAmount\\\":\\\"100\\\",\\\"peonURL\\\":\\\"https://pgp-automation.paytm.in/mockbank/MerchantSite/bankResponse\\\"}\",\"payOptionBillExtendInfo\":\"{\\\"totalTxnAmount\\\":\\\"100\\\",\\\"peonURL\\\":\\\"https://pgp-automation.paytm.in/mockbank/MerchantSite/bankResponse\\\"}\",\"payChannelInfo\":{\"virtualPaymentAddr\":\"sample@upi\",\"payOption\":\"UPI_PUSH_EXPRESS\",\"payerVpaCustomerId\":\"1232134235252\"}}],\"payRequestExtendInfo\":\"{\\\"totalTxnAmount\\\":\\\"100\\\",\\\"peonURL\\\":\\\"https://pgp-automation.paytm.in/mockbank/MerchantSite/bankResponse\\\"}\",\"extendInfo\":\"{\\\"totalTxnAmount\\\":\\\"100\\\",\\\"peonURL\\\":\\\"https://pgp-automation.paytm.in/mockbank/MerchantSite/bankResponse\\\"}\",\"revoked\":false},\"orderExtendInfo\":\"{\\\"totalTxnAmount\\\":\\\"100\\\",\\\"peonURL\\\":\\\"https://pgp-automation.paytm.in/mockbank/MerchantSite/bankResponse\\\"}\",\"merchantName\":\"SampleMerchantName\",\"payResult\":{\"resultStatus\":\"S\",\"resultCodeId\":\"00000000\",\"resultCode\":\"SUCCESS\",\"resultMsg\":\"success\"},\"timeoutExtendInfo\":\"{\\\"timeoutType\\\":\\\"EXPIRY_TIMEOUT\\\",\\\"disabled\\\":\\\"false\\\",\\\"timeoutInSeconds\\\":\\\"10\\\"}\"}";
      kafkaTemplate.send("TOPIC_PAYMENT_NOTIFY",test);
      log.info("SendingMessage" + " [" + s + "]");
    } catch (Exception exc) {
      log.error("Error while publishing", exc);
    }
  }

  public void sendMessage(String topic, String key, String unifiedData) {
    ListenableFuture<SendResult<String, String>> future = kafkaTemplate.send(topic, unifiedData);

    future.addCallback(
            new ListenableFutureCallback<SendResult<String, String>>() {

              @Override
              public void onSuccess(SendResult<String, String> result) {
                log.info(
                        "Sent message=[{}] with offset=[{}]",
                        unifiedData,
                        result.getRecordMetadata().offset());
              }

              @Override
              public void onFailure(Throwable ex) {
                log.info("Unable to send message=[{}] due to : {}", unifiedData, ex.getMessage());
              }
            });
  }
}
