package com.paytm.pgplus.notificationadapter.controlcenter;

public interface IApplicationCentre {


    boolean stopService();

    boolean isStopped();

    int getRequestCount();

    int incrementRequestCountAndGet();

    int decrementRequestCountAndGet();

}

