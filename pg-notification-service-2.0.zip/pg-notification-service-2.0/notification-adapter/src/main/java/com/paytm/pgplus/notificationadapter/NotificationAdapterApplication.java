package com.paytm.pgplus.notificationadapter;


import com.paytm.pgplus.notificationadapter.controlcenter.IApplicationCentre;
import com.paytm.pgplus.notificationadapter.controlcenter.NotificationAdapterApplicationCentreImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;


@SpringBootApplication
public class NotificationAdapterApplication {

	private static final Logger LOGGER= LoggerFactory.getLogger(NotificationAdapterApplication.class);

	public static void main(String[] args) {
		try{
			ConfigurableApplicationContext context=SpringApplication.run(NotificationAdapterApplication.class, args);

			Runtime.getRuntime().addShutdownHook(new Thread() {
				@Override
				public void run() {
					LOGGER.warn("Stopping Notification Adaptor !!!");
					final IApplicationCentre appConfig = context.getBean(NotificationAdapterApplicationCentreImpl.class);

					if (appConfig.stopService()) {
						LOGGER.warn("Notification Adaptor stopped!");
					} else {
						LOGGER.warn("Problem in stopping Notification Adaptor !!!");
					}

				context.close();
				}
			});
			
		}catch (Throwable e){
			LOGGER.error("Some Exception Occurred while starting Application!!!", e);
		}
	}

}
