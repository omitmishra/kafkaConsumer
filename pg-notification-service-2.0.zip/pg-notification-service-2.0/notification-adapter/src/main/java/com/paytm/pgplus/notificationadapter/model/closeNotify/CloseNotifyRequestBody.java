/**
 * 
 */
package com.paytm.pgplus.notificationadapter.model.closeNotify;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.pg.common.structures.ResultInfo;
import com.paytm.pgplus.notificationadapter.model.*;
import org.hibernate.validator.constraints.NotBlank;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CloseNotifyRequestBody extends AcquirementRequestBody {

    /**
     * Serial version UID
     */
    private static final long serialVersionUID = 5460236651056240386L;

    @NotBlank(message = "{notblank}")
    private String closedTime;

    @NotNull(message = "{notnull}")
    @Valid
    private ResultInfo closeResult;

    @NotBlank(message = "{notblank}")
    private String merchantId;

    @NotNull(message = "{notnull}")
    @Valid
    private Money orderAmount;

    @NotBlank(message = "{notblank}")
    private String createOrderTime;

    private String orderExtendInfo;

    private String productCode;

    private String orderModifyExtendInfo;

    private OrderPricingInfo orderPricingInfo;

    private String acquireMode;

    private List<PaymentView> paymentViews;

    /**
     * Acquiring failures identifier due to timeout or customer drop
     */
    private String closeSource;

    /**
     * Acquiring failures identifier due to timeout or customer drop
     */
    private String closeReason;

    public String getAcquireMode() {
        return acquireMode;
    }

    public void setAcquireMode(String acquireMode) {
        this.acquireMode = acquireMode;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    private List<SplitCommandInfo> splitCommandInfoList;

    /**
     * @return the closedTime
     */
    public String getClosedTime() {
        return closedTime;
    }

    /**
     * @param closedTime
     *            the closedTime to set
     */
    public void setClosedTime(String closedTime) {
        this.closedTime = closedTime;
    }

    /**
     * @return the closeResult
     */
    public ResultInfo getCloseResult() {
        return closeResult;
    }

    /**
     * @param closeResult
     *            the closeResult to set
     */
    public void setCloseResult(ResultInfo closeResult) {
        this.closeResult = closeResult;
    }

    public String getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(String merchantId) {
        this.merchantId = merchantId;
    }

    public Money getOrderAmount() {
        return orderAmount;
    }

    public void setOrderAmount(Money orderAmount) {
        this.orderAmount = orderAmount;
    }

    public String getCreateOrderTime() {
        return createOrderTime;
    }

    public void setCreateOrderTime(String createOrderTime) {
        this.createOrderTime = createOrderTime;
    }

    public String getOrderExtendInfo() {
        return orderExtendInfo;
    }

    public void setOrderExtendInfo(String orderExtendInfo) {
        this.orderExtendInfo = orderExtendInfo;
    }

    public String getOrderModifyExtendInfo() {
        return orderModifyExtendInfo;
    }

    public void setOrderModifyExtendInfo(String orderModifyExtendInfo) {
        this.orderModifyExtendInfo = orderModifyExtendInfo;
    }

    public OrderPricingInfo getOrderPricingInfo() {
        return orderPricingInfo;
    }

    public void setOrderPricingInfo(OrderPricingInfo orderPricingInfo) {
        this.orderPricingInfo = orderPricingInfo;
    }

    public List<SplitCommandInfo> getSplitCommandInfoList() {
        return splitCommandInfoList;
    }

    public void setSplitCommandInfoList(List<SplitCommandInfo> splitCommandInfoList) {
        this.splitCommandInfoList = splitCommandInfoList;
    }

    public List<PaymentView> getPaymentViews() {
        return paymentViews;
    }

    public void setPaymentViews(List<PaymentView> paymentViews) {
        this.paymentViews = paymentViews;
    }

    /**
     * @return
     */
    public String getCloseSource() {
        return closeSource;
    }

    /**
     * @param closeSource
     */
    public void setCloseSource(String closeSource) {
        this.closeSource = closeSource;
    }

    /**
     * @return
     */
    public String getCloseReason() {
        return closeReason;
    }

    /**
     * @param closeReason
     */
    public void setCloseReason(String closeReason) {
        this.closeReason = closeReason;
    }

    @Override
    public String toString() {
        return "CloseNotifyRequestBody{" + "closedTime='" + closedTime + '\'' + ", closeResult=" + closeResult
                + ", merchantId='" + merchantId + '\'' + ", orderAmount=" + orderAmount + ", createOrderTime='"
                + createOrderTime + '\'' + ", orderExtendInfo='" + orderExtendInfo + '\'' + ", productCode='"
                + productCode + '\'' + ", orderModifyExtendInfo='" + orderModifyExtendInfo + '\''
                + ", orderPricingInfo=" + orderPricingInfo + ", acquireMode='" + acquireMode + '\'' + ", paymentViews="
                + paymentViews + ", splitCommandInfoList=" + splitCommandInfoList + ", acquirementId='" + acquirementId
                + '\'' + ", merchantTransId='" + merchantTransId + '\'' + ", retryCount=" + retryCount + '\''
                + ", closeSource='" + closeSource + '\'' + ", closeReason=" + closeReason + '}';
    }
}
