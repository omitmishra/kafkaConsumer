package com.paytm.pgplus.notificationadapter.signature.encryption;

public class UtilityConstants {

    public static final int NO_OF_LAST_CHARS = 4;

    public static final String PIPE_TEXT = "|";

    public static final String ALPHA_NUM = "9876543210ZYXWVUTSRQPONMLKJIHGFEDCBAabcdefghijklmnopqrstuvwxyz!@#$&_";

    public static final String CHECKSUMHASH_TEXT = "CHECKSUMHASH";
    public static final String NULL_TEXT = "NULL";
    public static final String EMPTY_STRING = "";


}
