package com.paytm.pgplus.notificationadapter.http.constant;

public class AdapterCoreConstant {

    public static class PropertyConstant {
        public static final String ADAPTER_CORE_BASE_URL = "adapter.core.base.url";
    }
}
