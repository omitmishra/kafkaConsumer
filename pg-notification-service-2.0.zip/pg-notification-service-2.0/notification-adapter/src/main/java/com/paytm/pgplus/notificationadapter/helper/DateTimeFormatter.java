package com.paytm.pgplus.notificationadapter.helper;

import com.amazonaws.annotation.ThreadSafe;
import org.apache.commons.lang3.time.FastDateFormat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.Date;
import java.util.TimeZone;

public class DateTimeFormatter {

    private static final Logger LOGGER = LoggerFactory.getLogger(DateTimeFormatter.class);

    private static final TimeZone TIMEZONE;
    private static final String TIME_ZONE = "IST";
    private static final String ALIPAY_FORMAT = "yyyy-MM-dd'T'HH:mm:ssXXX";
    private static final FastDateFormat DATEFORMAT;
    static {
        TIMEZONE = TimeZone.getTimeZone(TIME_ZONE);
        DATEFORMAT = FastDateFormat.getInstance(ALIPAY_FORMAT, TIMEZONE);
    }


    public static String getISO861DateTimeString(Date date) {
       return DATEFORMAT.format(date);
    }

}
