package com.paytm.pgplus.notificationadapter.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import static com.paytm.pgplus.notificationadapter.util.NotificationAdapterConstants.Configurations.*;

@Configuration
public class KafkaClientConfig {

    private static final Logger LOGGER = LoggerFactory.getLogger(KafkaClientConfig.class);

    private static Properties configProps = null;

    static {
               // Initialize Project configurations
        loadKafkaClientConfig();
    }


    public static String getProperty(String key) {
        return configProps.getProperty(key);
    }

    public static String getPropertyByDefaultValue(String key, String defaultValue) {
        return configProps.getProperty(key, defaultValue);
    }

    private static void loadKafkaClientConfig() {
                if (configProps == null) {
                        synchronized (KafkaClientConfig.class) {
                                if (configProps == null) {
                                        InputStream inStream = null;
                                        try {
                                                configProps = new Properties();
                                                inStream = new FileInputStream(new File(PROPERTY_FILE_LOCATION));
                                                configProps.load(inStream);
                                                LOGGER.info("Initialized Project configuration from file : {}", PROPERTY_FILE_LOCATION);
                                            } catch (final Exception ex) {
                                                LOGGER.error("Exception in reading property file : " + PROPERTY_FILE_LOCATION, ex);
                                                System.exit(0);
                                            } finally {
                                                if (inStream != null) {
                                                        try {
                                                                inStream.close();
                                                            } catch (final IOException ex) {
                                                                LOGGER.error("Exception in closing file stream for : " + PROPERTY_FILE_LOCATION, ex);
                                                                   System.exit(0);
                                                            }
                                                    }
                                            }
                                    }
                            }
                    }
                LOGGER.debug("configProps : {}", configProps);
            }

}
