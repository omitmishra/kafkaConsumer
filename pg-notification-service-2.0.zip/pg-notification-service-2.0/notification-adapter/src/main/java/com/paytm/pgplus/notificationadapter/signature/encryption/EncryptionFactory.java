package com.paytm.pgplus.notificationadapter.signature.encryption;

public class EncryptionFactory {


    /**
     * Instantiates a new encryption factory.
     */
    private EncryptionFactory() {
    }

    /**
     * Gets the different encryption class based on the Algorithm type.
     *
     * @param algorithmType the encryption type
     * @return the encryption
     */
    public static Encryption getEncryptionInstance(String algorithmType) {

        Encryption encryption = null;
        if (EncryptConstants.ALGTHM_TYPE_AES.equalsIgnoreCase(algorithmType)) {
            encryption = new AesEncryption();
        }
        return encryption;

    }

}
