package com.paytm.pgplus.notificationadapter.model;


import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AcquirementRequestBody implements Serializable {
    /**
     * Serial version uid
     */
    private static final long serialVersionUID = 7174654313332665045L;

    /**
     * Transaction id created by AlipayPlus
     */
    @NotBlank(message = "{notblank}")
    @Length(max = 64, message = "{lengthlimit}")
    protected String acquirementId;

    /**
     * Merchant transaction id
     */
    @NotBlank(message = "{notblank}")
    @Length(max = 64, message = "{lengthlimit}")
    protected String merchantTransId;

    /**
     * Retry Count
     */
    protected int retryCount = 0;

    /**
     * @return the acquirementId
     */
    public String getAcquirementId() {
        return acquirementId;
    }

    /**
     * @param acquirementId
     *            the acquirementId to set
     */
    public void setAcquirementId(String acquirementId) {
        this.acquirementId = acquirementId;
    }

    /**
     * @return the merchantTransId
     */
    public String getMerchantTransId() {
        return merchantTransId;
    }

    /**
     * @param merchantTransId
     *            the merchantTransId to set
     */
    public void setMerchantTransId(String merchantTransId) {
        this.merchantTransId = merchantTransId;
    }

    /**
     * @return the retryCount
     */
    public int getRetryCount() {
        return retryCount;
    }

    /**
     * @param retryCount
     *            the retryCount to set
     */
    public void setRetryCount(int retryCount) {
        this.retryCount = retryCount;
    }

}

