package com.paytm.pgplus.notificationadapter.model.paymentNotify;

/**
 *
 */

import java.io.Serializable;
import java.util.Collections;
import java.util.Map;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.paytm.pgplus.notificationadapter.helper.JsonMapper;
import com.paytm.pgplus.notificationadapter.model.Money;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.validator.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PayOptionInfo implements Serializable {

    /**
     * default serial version uid
     */
    private static final long serialVersionUID = 504220718960496603L;

    @NotBlank(message = "{notnull}")
    private String payMethod;

    private String payOptionBillExtendInfo;

    @NotNull(message = "{notnull}")
    @Valid
    private Money payAmount;

    private Money transAmount;

    private Money chargeAmount;

    private Boolean revoked;

    private String extendInfo;

    private PayChannelInfo payChannelInfo;

    private DccPaymentInfo dccPaymentInfo;

    public Boolean getRevoked() {
        return revoked;
    }

    public void setRevoked(Boolean revoked) {
        this.revoked = revoked;
    }

    /**
     * @return the payMethod
     */
    public String getPayMethod() {
        return payMethod;
    }

    /**
     * @param payMethod
     *            the payMethod to set
     */
    public void setPayMethod(String payMethod) {
        this.payMethod = payMethod;
    }

    /**
     * @return the payAmount
     */
    public Money getPayAmount() {
        return payAmount;
    }

    /**
     * @param payAmount
     *            the payAmount to set
     */
    public void setPayAmount(Money payAmount) {
        this.payAmount = payAmount;
    }

    /**
     * @return the extendInfo
     */
    public String getExtendInfo() {
        return extendInfo;
    }

    /**
     * @param extendInfo
     *            the extendInfo to set
     */
    public void setExtendInfo(String extendInfo) {
        this.extendInfo = extendInfo;
    }

    /**
     * @return the transAmount
     */
    public Money getTransAmount() {
        return transAmount;
    }

    /**
     * @param transAmount
     *            the transAmount to set
     */
    public void setTransAmount(Money transAmount) {
        this.transAmount = transAmount;
    }

    /**
     * @return the chargeAmount
     */
    public Money getChargeAmount() {
        return chargeAmount;
    }

    /**
     * @param chargeAmount
     *            the chargeAmount to set
     */
    public void setChargeAmount(Money chargeAmount) {
        this.chargeAmount = chargeAmount;
    }

    public DccPaymentInfo getDccPaymentInfo() {
        return dccPaymentInfo;
    }

    public void setDccPaymentInfo(DccPaymentInfo dccPaymentInfo) {
        this.dccPaymentInfo = dccPaymentInfo;
    }

    public String getPayOptionBillExtendInfo() {
        return payOptionBillExtendInfo;
    }

    public void setPayOptionBillExtendInfo(String payOptionBillExtendInfo) {
        this.payOptionBillExtendInfo = payOptionBillExtendInfo;
    }

    public PayChannelInfo getPayChannelInfo() {
        return payChannelInfo;
    }

    public void setPayChannelInfo(PayChannelInfo payChannelInfo) {
        this.payChannelInfo = payChannelInfo;
    }

    @SuppressWarnings("unchecked")
    public Map<String, String> getExtendInfoMap() {
        try {
            if (StringUtils.isNotBlank(extendInfo)) {
                return JsonMapper.mapJsonToObject(extendInfo, Map.class);
            }
        } catch (final JsonProcessingException e) {
        }
        return Collections.emptyMap();
    }

    @SuppressWarnings("unchecked")
    public Map<String, String> getPayOptionBillExtendInfoMap() {
        try {
            if (StringUtils.isNotBlank(payOptionBillExtendInfo)) {
                return JsonMapper.mapJsonToObject(payOptionBillExtendInfo, Map.class);
            }
        } catch (final JsonProcessingException e) {
        }
        return Collections.emptyMap();
    }

    @Override
    public String toString() {
        return "PayOptionInfo [payMethod=" + payMethod + ", payOptionBillExtendInfo=" + payOptionBillExtendInfo
                + ", payAmount=" + payAmount + ", transAmount=" + transAmount + ", chargeAmount=" + chargeAmount
                + ", extendInfo=" + extendInfo + ", payChannelInfo=" + payChannelInfo + ", dccPaymentInfo="
                + dccPaymentInfo + "]";
    }

}