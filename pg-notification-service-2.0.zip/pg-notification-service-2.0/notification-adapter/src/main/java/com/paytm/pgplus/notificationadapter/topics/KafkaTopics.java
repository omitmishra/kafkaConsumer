package com.paytm.pgplus.notificationadapter.topics;

public class KafkaTopics {

    private KafkaTopics() {
    }

    public static final String TOPIC_PAYMENT_NOTIFY = "TOPIC_PAYMENT_NOTIFY";
    public static final String TOPIC_CLOSE_ORDER_NOTIFY = "TOPIC_CLOSE_ORDER_NOTIFY";
    public static final String TOPIC_PAYMENT_NOTIFY_RETRY="TOPIC_PAYMENT_NOTIFY_RETRY";
    public static final String TOPIC_CLOSE_ORDER_NOTIFY_RETRY="TOPIC_CLOSE_ORDER_NOTIFY_RETRY";




}