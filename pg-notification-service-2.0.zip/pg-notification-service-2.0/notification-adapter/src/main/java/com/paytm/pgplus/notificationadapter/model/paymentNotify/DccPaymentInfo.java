package com.paytm.pgplus.notificationadapter.model.paymentNotify;

import java.io.Serializable;

public class DccPaymentInfo implements Serializable {

    private static final long serialVersionUID = 8461830195495327463L;
    private String dccServiceInstId;
    private String dccSupported;
    private DccPaymentDetail dccPaymentDetail;

    public DccPaymentInfo() {
    }

    public DccPaymentInfo(String dccServiceInstId, String dccSupported, DccPaymentDetail dccPaymentDetail) {
        this.dccServiceInstId = dccServiceInstId;
        this.dccSupported = dccSupported;
        this.dccPaymentDetail = dccPaymentDetail;
    }

    public String getDccServiceInstId() {
        return dccServiceInstId;
    }

    public void setDccServiceInstId(String dccServiceInstId) {
        this.dccServiceInstId = dccServiceInstId;
    }

    public String getDccSupported() {
        return dccSupported;
    }

    public void setDccSupported(String dccSupported) {
        this.dccSupported = dccSupported;
    }

    public DccPaymentDetail getDccPaymentDetail() {
        return dccPaymentDetail;
    }

    public void setDccPaymentDetail(DccPaymentDetail dccPaymentDetail) {
        this.dccPaymentDetail = dccPaymentDetail;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("DccPaymentDetailResponse {");
        sb.append("dccServiceInstId=").append(dccServiceInstId);
        sb.append(", dccSupported=").append(dccSupported);
        sb.append(", dccPaymentDetail=").append(dccPaymentDetail);
        sb.append('}');
        return sb.toString();
    }
}

