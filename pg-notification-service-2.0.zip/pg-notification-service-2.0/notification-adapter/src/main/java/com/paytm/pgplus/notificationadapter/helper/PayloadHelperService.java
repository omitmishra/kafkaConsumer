package com.paytm.pgplus.notificationadapter.helper;

import com.paytm.pgplus.notificationadapter.model.closeNotify.CloseNotifyRequestBody;
import com.paytm.pgplus.notificationadapter.model.paymentNotify.PaymentNotifyRequestBody;
import com.paytm.pgplus.notificationadapter.signature.SignatureServiceHelper;
import com.paytm.pgplus.notificationadapter.signature.SignatureUtil;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
public class PayloadHelperService {


    @Autowired
    SignatureUtil signatureUtil;

    private static final Logger log = LoggerFactory.getLogger(PayloadHelperService.class);

    public String getPaymentNotifyPayload(PaymentNotifyRequestBody paymentNotifyRequestBody){
        JSONObject body = new JSONObject(paymentNotifyRequestBody);
        JSONObject payload = new JSONObject();
        JSONObject request = new JSONObject();
        JSONObject head = new JSONObject();
        {
            head.put("version", "1.1.4");
            head.put("function", "alipayplus.acquiring.order.paymentNotify");
            head.put("clientId", "2016030715243903536806");
            head.put("reqTime", DateTimeFormatter.getISO861DateTimeString(new Date()));
            head.put("reqMsgId", "a95eb8ed-86d7-4194-9216-15e19432c93d"); // have to ask abt this field
        }
        request.put("head", head);
        request.put("body", body);
        payload.put("request", request);
        payload.put("signature", getSignature(body.toString()));
        return payload.toString();
    }

    public String getCloseNotifyPayload(CloseNotifyRequestBody closeNotifyRequestBody){
        JSONObject body = new JSONObject(closeNotifyRequestBody);
        JSONObject payload = new JSONObject();
        JSONObject request = new JSONObject();
        JSONObject head = new JSONObject();
        {
            head.put("version", "1.1.4");
            head.put("function", "alipayplus.acquiring.order.closeNotify");
            head.put("clientId", "2016030715243903536806");
            head.put("reqTime", DateTimeFormatter.getISO861DateTimeString(new Date()));
            head.put("reqMsgId", "a95eb8ed-86d7-4194-9216-15e19432c93d"); // have to ask abt this field
        }
        request.put("head", head);
        request.put("body", body);
        payload.put("request", request);
        payload.put("signature", getSignature(body.toString()));
        return payload.toString();
    }

    public String getSignature(String body){
        String sig = "";
        try {
            SignatureServiceHelper  signatureServiceHelper=  SignatureServiceHelper.getInstance();
            sig= signatureServiceHelper.generateSignature(signatureUtil.sha256Key ,body);
        }catch (Exception e){
            log.error("Some exception occurred in generating Signature", e);
        }
        return sig;
    }
}
