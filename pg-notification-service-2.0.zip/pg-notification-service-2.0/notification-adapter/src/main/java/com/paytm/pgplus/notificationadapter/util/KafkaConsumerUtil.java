package com.paytm.pgplus.notificationadapter.util;


import com.paytm.pgplus.notificationadapter.controlcenter.IApplicationCentre;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.kafka.KafkaException;
import org.springframework.stereotype.Service;


@Service
public class KafkaConsumerUtil {

    private static final Logger LOGGER = LoggerFactory.getLogger(KafkaConsumerUtil.class);

    @Autowired
  //  @Qualifier("applicationCentre")
    protected IApplicationCentre applicationCentre;

    public void preConsume() {
        if (applicationCentre.isStopped()) {
            LOGGER.warn("Notification-Adapter Application is shutting down, No data will be consumed..");
            throw new KafkaException("Application terminating");
        }

    }

}
