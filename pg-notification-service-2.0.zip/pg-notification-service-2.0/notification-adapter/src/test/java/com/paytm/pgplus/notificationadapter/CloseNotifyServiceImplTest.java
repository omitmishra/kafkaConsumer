package com.paytm.pgplus.notificationadapter;


import com.paytm.pg.common.money.MultiCurrencyMoney;
import com.paytm.pg.common.structures.PayChannelInfoDTO;
import com.paytm.pg.common.structures.PayOptionDetailDTO;
import com.paytm.pg.common.structures.PaymentViewDTO;
import com.paytm.pg.dto.acquiring.CloseNotifyDTO;
import com.paytm.pgplus.notificationadapter.model.closeNotify.CloseNotifyRequestBody;
import com.paytm.pgplus.notificationadapter.service.impl.CloseNotifyServiceImpl;
import org.junit.Assert;
import org.junit.Before;
import org.junit.jupiter.api.Test;

import org.mockito.InjectMocks;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.reflect.Whitebox;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import java.util.ArrayList;
import java.util.Currency;
import java.util.List;


@SpringBootTest
@PrepareForTest(CloseNotifyServiceImpl.class)
public class CloseNotifyServiceImplTest {


    @InjectMocks
    private CloseNotifyServiceImpl closeNotifyServiceImpl;


    @Before
    public void setUp() {
        //inject mock instances by constructor
       closeNotifyServiceImpl= PowerMockito.spy(new CloseNotifyServiceImpl());
    }


    @Test
    public void setPaymentViews() throws Exception {
        CloseNotifyDTO cl=new CloseNotifyDTO();
        PaymentViewDTO pd=new PaymentViewDTO();
        CloseNotifyRequestBody crb=new CloseNotifyRequestBody();
        pd.setExtendInfo("abc");
        pd.setPaidTime("xyz");
        pd.setRevoked(false);
        List<PayOptionDetailDTO> payOptionInfos=new ArrayList<>();
        PayOptionDetailDTO pay=new PayOptionDetailDTO();
        MultiCurrencyMoney money=new MultiCurrencyMoney();
        Currency c=Currency.getInstance("INR");
        money.setCurrency(c);
        String code=c.getCurrencyCode();

        money.setCurrencyValue("123");
        pay.setExtendInfo("cash");
        pay.setPayMethod("UPI");
        pay.setTransAmount(money);
        payOptionInfos.add(pay);
        pay.setTransAmount(money);
        pay.setPayAmount(money);
        PayChannelInfoDTO pf=new PayChannelInfoDTO();
        pf.setVirtualPaymentAddr("qaaaaa");
        pf.setPayerVpaCustomerId("custid");
        pf.setVirtualPaymentAddr("qweee");
        pay.setPayChannelInfo(pf);
        pd.setPayOptionInfos(payOptionInfos);
        pd.setPayRequestExtendInfo("kdldd");

        List<PaymentViewDTO> list=new ArrayList<>();
        list.add(pd);
        cl.setPaymentViews(list);
        CloseNotifyServiceImpl cn=new CloseNotifyServiceImpl();
       Whitebox.invokeMethod(closeNotifyServiceImpl,"setPaymentViews",crb,cl);





    }

}