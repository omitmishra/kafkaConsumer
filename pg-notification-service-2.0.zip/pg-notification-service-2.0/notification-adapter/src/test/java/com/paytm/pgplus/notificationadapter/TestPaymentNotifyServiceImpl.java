package com.paytm.pgplus.notificationadapter;


import com.paytm.pg.common.money.MultiCurrencyMoney;
import com.paytm.pg.common.structures.PayChannelInfoDTO;
import com.paytm.pg.common.structures.PayOptionDetailDTO;
import com.paytm.pg.common.structures.PaymentViewDTO;
import com.paytm.pg.dto.acquiring.PaymentNotifyDTO;
import com.paytm.pgplus.notificationadapter.model.paymentNotify.PaymentNotifyRequestBody;
import com.paytm.pgplus.notificationadapter.service.impl.PaymentNotifyServiceImpl;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;
import org.springframework.boot.test.mock.mockito.MockBean;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Currency;
import java.util.List;

@RunWith(PowerMockRunner.class)
@PrepareForTest(PaymentNotifyServiceImpl.class)
public class TestPaymentNotifyServiceImpl {

    @InjectMocks
    PaymentNotifyServiceImpl paymentNotifyService;

    @Test
    public void testPrivateProcessPaymentNotify() throws Exception{
        PaymentNotifyDTO paymentNotifyDTO=new PaymentNotifyDTO();
        PaymentViewDTO paymentViewDTO=new PaymentViewDTO();
        paymentViewDTO.setPaidTime("123");
        paymentViewDTO.setCashierRequestId("abc");
        paymentViewDTO.setRevoked(true);
        paymentViewDTO.setExtendInfo("");
        paymentViewDTO.setPayRequestExtendInfo("");
        PayOptionDetailDTO payOptionDetailDTO=new PayOptionDetailDTO();
        MultiCurrencyMoney money=new MultiCurrencyMoney("1234");
        payOptionDetailDTO.setPayAmount(money);
        payOptionDetailDTO.setPayMethod("Credit card");
        payOptionDetailDTO.setTransAmount(money);
        payOptionDetailDTO.setExtendInfo("");
        payOptionDetailDTO.setPayOptionBillExtendInfo("");
        PayChannelInfoDTO payChannelInfoDTO=new PayChannelInfoDTO();
        payChannelInfoDTO.setPayOption("Credit card");
        payChannelInfoDTO.setVirtualPaymentAddr("/paytm/address");
        payChannelInfoDTO.setPayerVpaCustomerId("123");
        payOptionDetailDTO.setPayChannelInfo(payChannelInfoDTO);
        List<PayOptionDetailDTO> payOptionInfos=new ArrayList<>();
        payOptionInfos.add(payOptionDetailDTO);
        paymentViewDTO.setPayOptionInfos(payOptionInfos);
        paymentNotifyDTO.setPaymentView(paymentViewDTO);
        PaymentNotifyRequestBody paymentNotifyRequestBody=new PaymentNotifyRequestBody();
        String result= Whitebox.invokeMethod(paymentNotifyService,"setPaymentView",paymentNotifyRequestBody,paymentNotifyDTO);
      //  System.out.println(result);
     //   Assert.assertEquals("",result);
    }





}
